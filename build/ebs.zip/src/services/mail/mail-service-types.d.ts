interface SendMailParam {
    recipientList: string[],
    ccList: string[],
    subject: string,
    html: string
}